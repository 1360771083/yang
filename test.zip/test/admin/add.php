<html>
<body>
    <form action="add.handle.php" method="post">
        name:<input type="text" name="name"><br>
        content:<input type="text" name="content"><br>
        price:<input type="text" name="price"><br>
        <input type="submit" value="�ύ">
    </form>
</body>
</html>